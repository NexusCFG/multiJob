Config = {}
-- ONLY HAVE ONE OF THESE SET TO TRUE!
Config.usingQBmenu = false -- If you want to use the QB Menu, set this to true.
Config.usingRenzuContext = true --- If you want to use the Renzu Context Menu, set this to true. https://github.com/renzuzu/renzu_contextmenu
-- ^^^^^^ ONLY HAVE ONE OF THESE SET TO TRUE!

Config.OpenKey = 'NUMPAD9' -- The key to open the menu.